/**
 * Created by gleicher on 10/17/15.
 */
var grobjects = grobjects || [];

// make the two constructors global variables so they can be used later
var Copter = undefined;
var Helipad = undefined;

/* this file defines a helicopter object and a helipad object

the helicopter is pretty ugly, and the rotor doesn't spin - but
it is intentionally simply. it's ugly so that students can make
it nicer!

it does give an example of index face sets

read a simpler object first.


the helipad is a simple object for the helicopter to land on.
there needs to be at least two helipads for the helicopter to work..


the behavior of the helicopter is at the end of the file. it is
an example of a more complex/richer behavior.
 */

(function () {
    "use strict";

    // i will use this function's scope for things that will be shared
    // across all cubes - they can all have the same buffers and shaders
    // note - twgl keeps track of the locations for uniforms and attributes for us!
    var shaderProgram = undefined;
    var copterBodyBuffers = undefined;
    var copterRotor1Buffers = undefined;
	var copterRotor2Buffers = undefined;
    var copterNumber = 0;

    var padBuffers = undefined;
    var padNumber = 0;

    // constructor for Helicopter
    Copter = function Copter(name) {
        this.name = "copter"+copterNumber++;
        this.position = [0,0,0];    // will be set in init
        this.color = [.5,.7,.4];
        // about the Y axis - it's the facing direction
        this.orientation = 0;
		this.rotor_angle1 = 0;
		this.rotor_angle2 = 0;
    }
    Copter.prototype.init = function(drawingState) {
        var gl=drawingState.gl;
        var q = .25;  // abbreviation

        // create the shaders once - for all cubes
        if (!shaderProgram) {
            shaderProgram = twgl.createProgramInfo(gl, ["coptor-vs", "coptor-fs"]);
        }
		this.shaderProgram = shaderProgram.program;
		
		var body_vpos = new Float32Array([
			.5, 0, 0,  0,0,.5,  -.5,0,0,  0,0, -.5,  0,.5,0,    
			0, -.5,0, q,0,-q,  0,q,-q,  -q,0,-q,  0,-q,-q,  0,0,-1]);
			
		var body_vnormal = new Float32Array([
			1,0,0,  0,0,1,  -1,0,0,  0,0,-1, 0,1,0,  0,-1,0,
            1,0,0,  0,1,0,  -1,0,0,  0,-1,0,  0,0,-1]);	
			
		var body_texCoord = new Float32Array([
			0,0, 1,0, 1,1, 0,1, 1,0, 
			0,0, 1,0, 1,1, 0,1, 1,0, 0,0]);
			
		this.body_indices = new Uint16Array([
			0,1,4, 1,2,4, 2,3,4, 3,0,4, 1,0,5, 2,1,5, 3,2,5, 0,3,5,
            6,7,10, 7,8,10, 8,9,10, 9,6,10]);	
		
		
		var rotor1_vpos = new Float32Array([0,.5,0, 1,.5,.1, 1,.5, -.1,
                                            0,.5,0, -1,.5,.1, -1,.5, -.1]);
		var rotor1_vnormal = new Float32Array([0,1,0, 0,1,0, 0,1,0, 0,1,0, 0,1,0, 0,1,0]);
		this.rotor1_indices = new Uint16Array([0,1,2, 3,4,5]);									
				
		var rotor2_vpos = new Float32Array([0,0,-1, 0.25,0.25,-1,  0.25,-0.25,-1,
                                            0,0,-1, -0.25,0.25,-1, -0.25,-0.25,-1]);
		var rotor2_vnormal = new Float32Array([0,0,1, 0,0,1, 0,0,1, 0,0,1, 0,0,1, 0,0,1]);
		this.rotor2_indices = new Uint16Array([0,1,2, 3,4,5]);
		
		
		// a buffer for vpos
		this.PosBuffer_body = gl.createBuffer();
		gl.bindBuffer(gl.ARRAY_BUFFER, this.PosBuffer_body);
		gl.bufferData(gl.ARRAY_BUFFER, body_vpos, gl.STATIC_DRAW);
		
		// a buffer for vnormal
		this.normBuffer_body = gl.createBuffer();
		gl.bindBuffer(gl.ARRAY_BUFFER, this.normBuffer_body);
		gl.bufferData(gl.ARRAY_BUFFER, body_vnormal, gl.STATIC_DRAW);
		
		// a buffer for texture
		this.texCoordBuffer_body = gl.createBuffer();
		gl.bindBuffer(gl.ARRAY_BUFFER, this.texCoordBuffer_body);
		gl.bufferData(gl.ARRAY_BUFFER, body_texCoord, gl.STATIC_DRAW);
		 
		var img_body = new Image();
		img_body.crossOrigin = "anonymous";
		img_body.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAIAAADTED8xAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAwkSURBVHhe7dVdluM4roXRGkg/1jxzxD2GLOXyh0gaRDhsiaQk4Ox1HvpmWPwBgVv//BIpTAMgpWkApDQNgJSmAZDSNABSmgZAStMASGkaAClNAyClaQCkNA2AlKYBkNI0AFKaBkBK0wBIaRoAKU0DIKVpAKQ0DYCUpgGQ0jQAUpoGQErTAEhpGgApTQMgpWkApDQNgJSmAZDSNABSmgZAStMASGkaAClNAyClaQDO9I/h/5blVPrT0PuGf5W1VPfT0PiGf5W1VPfT0PiGf5W1VPdz0PXP+JsspKKfg5Z/xt9kIRX9HLT8M/4mC6noJ6DfI/xCVlHFT0CzR/iFrKKKn4Bmj/ALWUUVX41O/x6/kyVU7tVoc/P///3L/zL8TpZQuVejzY0G4Fwq91L0uNm6vx+ADb+W+VTrpWhw8xgA/UfgRKr1UjS40QCcTrVeh+42X93fD8CGb2QyFXodWtu0A9DPAN/IZCr0OrS20QBcgQq9CH1tXPdv4Q8NvpSZVOVFaGrjuv8R/mb4UmZSlRehqY1r/Uf4m+FLmUlVXoGONq7vv8KfG3wv06jEK9DOxvV9G35h+F6mUYlXoJ2Na/o2/MLwvUyjEk9HLxvX8S78qMEqMofqOx2NbFzH9+F3hlVkDtV3OhrZuHbvw+8Mq8gcqu9cdLFxvR6GnxoWkjlU37noYuN6PQw/bbCWTKDizkULG9fr34VfG9aSCVTciehf47r8RfjAsJxMoOJORP8a1+UvwgcNVpTRVNmJaF7juvx1+Mawooymys5C5xrX3z+GzwyLymiq7Cx0rnH9/WP4rMG6MpTKOgtta1x/vxO+NKwrQ6msU9CzxnX2m+Fjw9IylMo6BT1rXGe/GT5usLqMo5pOQcMa19nvh+8Nq8s4qul4dKtxPf1RWMKwgYyjmo5HtxrX0x+FJRrsIYOooOPRqsb19KdhFcMeMogKOhh9alw37wgLGbaRQVTQwehT47p5R1iowU4ygqo5GE1qXDfvC2sZdpIRVM2R6FDj+nh3WM6wmYygao5EhxrXx7vDcg32k8NUypFoT+P6+EhY0bCfHKZSDkNvGtfBB8Oihi3lMJVyGHrTuA4+GBY1bCmHqZTD0JvGdfDBsGiDXeUY1XEMutK49h0SljZsLMeojmPQlcb17pCwtGFjOUZ1HIOuNK53h4SlG+wtB6iIA9CPxjXuwLCBYXs5QEUcgH40rmsHhg0M28sBKuIA9KNxXTswbNDgBLKXKngUnWhcyw4P2xgOIXupgkfRicb16/CwjeEQspcqeBSdaFy/Dg/bNDiH7KLyHUIPGtesk8JmhqPILirfIfSgcZ06KWxmOIrsovIdQg8a16mTwmYNTiOfU+32o/uMa9OpYUvDgeRzqt1+dJ9xPTo1bGk4kHxOtduP7jOuR6eGLRucST6kwu1E3xnXoAvCxoZjyYdUuJ3oO+O6c0HY2HAs+ZAK9wdNdIDrzgVh4wO4fG3XrQKvdAeuNZeF7e+AR72euSfj9tm5vlwWts+OZppj4uocvwDXl8vC9gXQUhNoAI5yTbk4HCI7WmoCDcAfrquKhMvfAS01wcSlNxx/F/dayq3Do+5CM80xd/UNl4i4GillQ0NEaKNppm/wwG06rhBKwdAKHVpnskXbbLhWx5VDKRWaoEPTzLdupw2Xi7i6KOnDw0dolyWWbvbALTuuQEri8OQdWmShE7bccN2Iq5SSLDxzhOZY65xdN1w64kqmpAkPHKEtljtt4wdu33GFUxKEp+3QCic5efsNZYi4Cio3Dc8ZoQnOc/4JHqhHx5VSuV14yAhvf6qrDMCGqnRcQZUbhSfs8OQXcKGjbChPxFVWuXh4tgiPfQ3XOs0Ddeq4EiuXDQ/W4YGv5Ipn2lCwjiu0csHwVB2e9mIueqwNZYu4iisXCc8T4VGv57one6B+HVd65fTwMB0e8qqufr4Nhey4B1BODE/S4Qkv7AZH3FDOiHsJZXF4hgiPd233OOUDde24J1GWhQfo8GB3cKezbihwxL2NMjUUPcJT3cTNjruhzBH3SMqkUO4Ij3Qf9zvxA/XuuKdShodCd3iYu7nruTcUPuLeTBkSihvhSW7oxkd/4AU67vGUg6GsEV7inm4/ABveoeOeUNkdCtrhAe4swx02PEjEvaXyUShihNLfXJJrPPAyHfeoypuhfB3KnUKqy2x4oo57WuXHULgOhc4i2302PFTEvbEShmJFKHEiCa/0wIt13GMrLpSpQ1nTSXuxDU/XcU+ufIUCdShoRpnvtuEBI+7ti4eiRChlUsmv98BLdlwTlA3l6FC+1EpccsOTRlw3lAoliFC47Krcc8PDRlxbFAmXj1CyAgpd9YEX7rjmSB+u3aFMZZS78IanjrguSRmuGqFAlVS88wNv3nHtkixcMkJdiqk7ABtevuOaJk24XodylFT68hta4JnrmzThes8oRFXV7/9ALxjXN2nC9QyXr01VCP4j4PomU7ihoQSFqQRV/t//I1zSUILCVAINQGnVS0AjNFzHJAuXbFCIqjQAT1y7pAxXNRSiKg3AE9crKcNVDYWoqvT9aYGG65WU4aoNylGSBuAv1yiJw4UN5ShJA/CX65LE4cKGcpSkAfjLdUnicGFDOUqqe3kev+G6JHe4s6Eo9WgA4Pojfbi2oSj1aADg+iN9uLahKPUUvTnP3nD9kT5cu0FpitEA/OGao0i4vKE0xWgA/nCdUSRc3lCaYipemwdvuM4oEi7foECVaACKdv8jlMBQoEo0ABqAvyhQJRoADcATalRGvQs/cw1RMBTCUKYyNAC+IaqFQhjKVIYGwDdEtVAIQ5nKqHVhHrnhuqFmqIWhWDWUHgDXB2VDOQzFqkEDcGY4x9kn4RCGYtVQ6LY8b8P1weJwiIb7wbKwfYOSFVB3AFwTrAwniLhfLgvbG0pWgAZgddj+e+73a8LehpIVUOWqPGzDdcCCsPF73Lezw64NCpdd0QFwz78gbPwJt8LssKuhcNlpAKaHLSMcLvoP1Be32rywn+Fk2WkA5ob9IpzM8K8Rt+aksJnhWNmVuCdP2nBvPyPsFOFYEX4RcevPCDsZzpRaxQFwrz4j7BThTN/jdxG3y/CwjeFAqWkABoc9IpzmPXwTcTsODBsYjpJa/kvymA336gPDBhFO8wm+jLh9R4XVGxwlr3ID4J58VFg9wjn2YpWIO8OQsLThEHlpAAaEpSMc4hjWiriTHA/rGk6QV/Ib8owN994Hw6IRTjAO60bcqY6EFRtsn1StAXCPfTAsGmH70Vg94s52JKxo2DspDcCesFyEjWdip4g7576wlmHXpDQAH4e1Iuw6H/tF3Gl3hIUa7JpR6rs9c8+8IywUYcu12DviTv5pWMWwX0YagHfDKhH2OwMniLjzfxSWMGyWkQbg5/B9hJ3Oxmki7i5vho8N22SU9m48XcO98Zvh4wg7XQNnirgbvRk+NmyTTpUBcK/7Tvgywh4Xw+Ei7mrvhC8Ne6SjAYjDZxE2uCpOGXF3fB2+MayeTs6L8WgN97ovwgcRVr88jhtxl30RPmiwei4lBsA97YvwQYSl74NzR9ytvwu/NqybiwaA8NMIi94QF4i464fhp4ZFc0l4K56r4d61D7+LsOidcZOIq4MLP2qwYiL5B8A9qgs/irBcClwp4griwo8MyyVSegD4RYS1cuFuEVeZr/Bnw0KJFB0A/hZhlaS4ZMSV6BH+ZlglkWxX4qEa7kW38IcIq2THbSOuVlv4g2GJLJIPwOu3bPF9GVw78rpofJ9FoQHgnyJ8XA/3j3xXN77MItV9eKKGWv9HFCLyXfX4MoXMA6Dufx8Vifz+/Zv/ZfgmhcwD8AIfSIPSvIEPUshzGR7nDXwgEWr0E359f7UGgJ/KSxTrJX56f4UGgN/Je6jaN/jR/ZUYAH4hH6J83+BHN5flGt/jF7IXdezw55vLPAD8TQ6joM/4282lHQD+IINQ1gZ/uLk8jcKzqPVnosSJiqx2kdI0AFKaBkBK0wBIaRoAKU0DIKVpAKQ0DYCUpgGQ0jQAUpoGQErTAEhpGgApTQMgpWkApDQNgJSmAZDSNABSmgZAStMASGkaAClNAyClaQCkNA2AlKYBkNI0AFKaBkBK0wBIaRoAKU0DIKVpAKQ0DYCUpgGQ0jQAUpoGQAr79es/0nwqsBxwJN4AAAAASUVORK5CYII=";
		
		// a buffer for indices
		this.indexBuffer_body = gl.createBuffer();
		gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.indexBuffer_body);
		gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, this.body_indices, gl.STATIC_DRAW);
		
		
		// a buffer for vpos
		this.PosBuffer_rotor1 = gl.createBuffer();
		gl.bindBuffer(gl.ARRAY_BUFFER, this.PosBuffer_rotor1);
		gl.bufferData(gl.ARRAY_BUFFER, rotor1_vpos, gl.STATIC_DRAW);
		this.PosBuffer_rotor1.itemSize = 3;
		this.PosBuffer_rotor1.numItems = 24;
		
		// a buffer for vnormal
		this.normBuffer_rotor1 = gl.createBuffer();
		gl.bindBuffer(gl.ARRAY_BUFFER, this.normBuffer_rotor1);
		gl.bufferData(gl.ARRAY_BUFFER, rotor1_vnormal, gl.STATIC_DRAW);
		this.normBuffer_rotor1.itemSize = 3;
		this.normBuffer_rotor1.numItems = 24;

		// a buffer for indices
		this.indexBuffer_rotor1 = gl.createBuffer();
		gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.indexBuffer_rotor1);
		gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, this.rotor1_indices, gl.STATIC_DRAW);
		
		// a buffer for vpos
		this.PosBuffer_rotor2 = gl.createBuffer();
		gl.bindBuffer(gl.ARRAY_BUFFER, this.PosBuffer_rotor2);
		gl.bufferData(gl.ARRAY_BUFFER, rotor2_vpos, gl.STATIC_DRAW);
		this.PosBuffer_rotor2.itemSize = 3;
		this.PosBuffer_rotor2.numItems = 24;
		
		// a buffer for vnormal
		this.normBuffer_rotor2 = gl.createBuffer();
		gl.bindBuffer(gl.ARRAY_BUFFER, this.normBuffer_rotor2);
		gl.bufferData(gl.ARRAY_BUFFER, rotor2_vnormal, gl.STATIC_DRAW);
		this.normBuffer_rotor2.itemSize = 3;
		this.normBuffer_rotor2.numItems = 24;

		// a buffer for indices
		this.indexBuffer_rotor2 = gl.createBuffer();
		gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.indexBuffer_rotor2);
		gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, this.rotor2_indices, gl.STATIC_DRAW);
		
		
		this.posLoc = gl.getAttribLocation(this.shaderProgram, "vpos");
		this.normalLoc = gl.getAttribLocation(this.shaderProgram, "vnormal");
		this.texCoordLoc = gl.getAttribLocation(this.shaderProgram, "texCoord");
		
        this.projLoc = gl.getUniformLocation(this.shaderProgram,"proj");
        this.viewLoc = gl.getUniformLocation(this.shaderProgram,"view");
		this.modelLoc = gl.getUniformLocation(this.shaderProgram,"model");
		this.normalMLoc = gl.getUniformLocation(this.shaderProgram,"normalMatrix");
        this.caLoc = gl.getUniformLocation(this.shaderProgram,"ca");
		this.cdLoc = gl.getUniformLocation(this.shaderProgram,"cd");
		this.csLoc = gl.getUniformLocation(this.shaderProgram,"cs"); 
		this.sExpLoc = gl.getUniformLocation(this.shaderProgram,"sExp");
		this.lightPosLoc = gl.getUniformLocation(this.shaderProgram,"lightPos");
		this.lightColLoc = gl.getUniformLocation(this.shaderProgram,"lightCol");
		this.texSampler = gl.getUniformLocation(this.shaderProgram,"texSampler");
		
		this.body_Texture = gl.createTexture();
		gl.bindTexture(gl.TEXTURE_2D, this.body_Texture);
		gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
		gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA,gl.UNSIGNED_BYTE,img_body);
		gl.bindTexture(gl.TEXTURE_2D, null);
			
        // put the helicopter on a random helipad
        // see the stuff on helicopter behavior to understand the thing
        this.lastPad = randomHelipad();
        this.position = twgl.v3.add(this.lastPad.center(),[0,.5+this.lastPad.helipadAltitude,0]);
        this.state = 0; // landed
        this.wait = getRandomInt(250,750);
        this.lastTime = 0;

    };
    Copter.prototype.draw = function(drawingState) {
        // make the helicopter fly around
        // this will change position and orientation
        advance(this,drawingState);
		var gl = drawingState.gl;

		/*
		 * draw the body of copter
		 */
        gl.useProgram(shaderProgram.program);
		
		gl.enableVertexAttribArray(this.posLoc);
		gl.enableVertexAttribArray(this.normalLoc);
		gl.enableVertexAttribArray(this.texCoordLoc);
		
		// we make a model matrix to place the cube in the world
        var modelM_body = twgl.m4.rotationY(this.orientation);
        twgl.m4.setTranslation(modelM_body, this.position, modelM_body);
		
		// normMatrix
		var normMatrix_body = new Float32Array(16);
		twgl.m4.transpose(twgl.m4.inverse(twgl.m4.multiply(modelM_body, drawingState.view)), normMatrix_body);
		
		gl.uniformMatrix4fv(this.viewLoc,false,drawingState.view);
        gl.uniformMatrix4fv(this.projLoc,false,drawingState.proj);
		gl.uniformMatrix4fv(this.modelLoc,false,modelM_body);
        gl.uniformMatrix4fv(this.normalMLoc,false,normMatrix_body);
		gl.uniform1f(this.caLoc, drawingState.ca);
        gl.uniform1f(this.cdLoc, drawingState.cd);
		gl.uniform1f(this.csLoc, drawingState.cs);
        gl.uniform1f(this.sExpLoc, drawingState.sExp);
		gl.uniform3f(this.lightPosLoc,drawingState.sunDirection[0],drawingState.sunDirection[1],drawingState.sunDirection[2]);
        gl.uniform3f(this.lightColLoc, 1, 1, 1);
		gl.uniform1i(this.texSampler, 0);
			
        // connect the attributes to the buffer
        gl.bindBuffer(gl.ARRAY_BUFFER, this.PosBuffer_body);
        gl.vertexAttribPointer(this.posLoc, 3, gl.FLOAT, false, 0, 0);
		gl.bindBuffer(gl.ARRAY_BUFFER, this.normBuffer_body);
        gl.vertexAttribPointer(this.normalLoc, 3, gl.FLOAT, false, 0, 0);
		gl.bindBuffer(gl.ARRAY_BUFFER, this.texCoordBuffer_body);
        gl.vertexAttribPointer(this.texCoordLoc, 2, gl.FLOAT, false, 0, 0);
		
		// Bind texture
		gl.bindTexture(gl.TEXTURE_2D, this.body_Texture);
		gl.activeTexture(gl.TEXTURE0);
			
		gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.indexBuffer_body);
		gl.drawElements(gl.TRIANGLES, this.body_indices.length, gl.UNSIGNED_SHORT, 0);
		
		// draw rotor 1
		// connect the attributes to the buffer
		var modelM_rotor1 = twgl.m4.multiply(twgl.m4.rotationY(this.rotor_angle1),twgl.m4.rotationY(this.orientation));
		this.rotor_angle1 = this.rotor_angle1 + (10 * Math.PI)/200;
        twgl.m4.setTranslation(modelM_rotor1, this.position, modelM_rotor1);
		var normMatrix_rotor1 = new Float32Array(16);
		twgl.m4.transpose(twgl.m4.inverse(twgl.m4.multiply(modelM_rotor1, drawingState.view)), normMatrix_rotor1);
		
		gl.uniformMatrix4fv(this.modelLoc,false,modelM_rotor1);
        gl.uniformMatrix4fv(this.normalMLoc,false,normMatrix_rotor1);
		
        gl.bindBuffer(gl.ARRAY_BUFFER, this.PosBuffer_rotor1);
        gl.vertexAttribPointer(this.posLoc, 3, gl.FLOAT, false, 0, 0);
		gl.bindBuffer(gl.ARRAY_BUFFER, this.normBuffer_rotor1);
        gl.vertexAttribPointer(this.normalLoc, 3, gl.FLOAT, false, 0, 0);
			
		gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.indexBuffer_rotor1);
		gl.drawElements(gl.TRIANGLES, this.rotor1_indices.length, gl.UNSIGNED_SHORT, 0);
		
		// draw rotor 2
		// connect the attributes to the buffer
		var modelM_rotor2 = twgl.m4.multiply(twgl.m4.rotationZ(this.rotor_angle2),twgl.m4.rotationY(this.orientation));
		this.rotor_angle2 = this.rotor_angle2 + (10 * Math.PI)/200;
        twgl.m4.setTranslation(modelM_rotor2, this.position, modelM_rotor2);
		var normMatrix_rotor2 = new Float32Array(16);
		twgl.m4.transpose(twgl.m4.inverse(twgl.m4.multiply(modelM_rotor2, drawingState.view)), normMatrix_rotor2);
		
		gl.uniformMatrix4fv(this.modelLoc,false,modelM_rotor2);
        gl.uniformMatrix4fv(this.normalMLoc,false,normMatrix_rotor2);
		
        gl.bindBuffer(gl.ARRAY_BUFFER, this.PosBuffer_rotor2);
        gl.vertexAttribPointer(this.posLoc, 3, gl.FLOAT, false, 0, 0);
		gl.bindBuffer(gl.ARRAY_BUFFER, this.normBuffer_rotor2);
        gl.vertexAttribPointer(this.normalLoc, 3, gl.FLOAT, false, 0, 0);
			
		gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.indexBuffer_rotor2);
		gl.drawElements(gl.TRIANGLES, this.rotor2_indices.length, gl.UNSIGNED_SHORT, 0);
    };
    Copter.prototype.center = function(drawingState) {
        return this.position;
    }


    // constructor for Helipad
    // note that anything that has a helipad and helipadAltitude key can be used
    Helipad = function Helipad(position) {
        this.name = "helipad"+padNumber++;
        this.position = position || [2,0.01,2];
        this.size = 1.0;
        // yes, there is probably a better way
        this.helipad = true;
        // what altitude should the helicopter be?
        // this get added to the helicopter size
        this.helipadAltitude = 0;
    }
    Helipad.prototype.init = function(drawingState) {
        var gl=drawingState.gl;
        var q = .25;  // abbreviation

        // create the shaders once - for all cubes
        if (!shaderProgram) {
            shaderProgram = twgl.createProgramInfo(gl, ["cube-vs", "cube-fs"]);
        }
        if (!padBuffers) {
            var arrays = {
                vpos : { numComponents: 3, data: [
                    -1,0,-1, -1,0,1, -.5,0,1, -.5,0,-1,
                    1,0,-1, 1,0,1, .5,0,1, .5,0,-1,
                    -.5,0,-.25, -.5,0,.25,.5,0,.25,.5,0, -.25

                ] },
                vnormal : {numComponents:3, data: [
                    0,1,0, 0,1,0, 0,1,0, 0,1,0,
                    0,1,0, 0,1,0, 0,1,0, 0,1,0,
                    0,1,0, 0,1,0, 0,1,0, 0,1,0
                ]},
                indices : [0,1,2, 0,2,3, 4,5,6, 4,6,7, 8,9,10, 8,10,11
                            ]
            };
            padBuffers = twgl.createBufferInfoFromArrays(drawingState.gl,arrays);
        }

    };
    Helipad.prototype.draw = function(drawingState) {
		/*
        // we make a model matrix to place the cube in the world
        var modelM = twgl.m4.scaling([this.size,this.size,this.size]);
        twgl.m4.setTranslation(modelM,this.position,modelM);
        // the drawing coce is straightforward - since twgl deals with the GL stuff for us
        var gl = drawingState.gl;
        gl.useProgram(shaderProgram.program);
		
		// normMatrix
		var normMatrix = new Float32Array(16);
		twgl.m4.transpose(twgl.m4.inverse(twgl.m4.multiply(modelM, drawingState.view)), normMatrix);
		
        twgl.setUniforms(shaderProgram,{
            view:drawingState.view, proj:drawingState.proj, lightdir:drawingState.sunDirection,
            cubecolor:[1,1,0], model: modelM, normalMatrix: normMatrix,
			ca: drawingState.ca, cd: drawingState.cd, cs: drawingState.cs, sExp: drawingState.sExp});
			
        twgl.setBuffersAndAttributes(gl,shaderProgram,padBuffers);
        twgl.drawBufferInfo(gl, gl.TRIANGLES, padBuffers);
		*/
    };
    Helipad.prototype.center = function(drawingState) {
        return this.position;
    }

    ///////////////////////////////////////////////////////////////////
    // Helicopter Behavior
    //
    // the guts of this (the "advance" function) probably could
    // have been a method of helicopter.
    //
    // this is all kept separate from the parts that draw the helicopter
    //
    // the idea is that
    // the helicopter starts on a helipad,
    // waits some random amount of time,
    // takes off (raises to altitude),
    // picks a random helipad to fly to,
    // turns towards that helipad,
    // flies to that helipad,
    // lands
    //
    // the helicopter can be in 1 of 4 states:
    //      landed  (0)
    //      taking off (1)
    //      turning towards dest (2)
    //      flying towards dest (3)
    //      landing (4)


    ////////////////////////
    // constants
    var altitude = 3;
    var verticalSpeed = 3 / 1000;      // units per milli-second
    var flyingSpeed = 3/1000;          // units per milli-second
    var turningSpeed = 2/1000;         // radians per milli-second

    // utility - generate random  integer
    function getRandomInt(min, max) {
        return Math.floor(Math.random() * (max - min)) + min;
    }
    // find a random helipad - allow for excluding one (so we don't re-use last target)
    function randomHelipad(exclude) {
        var helipads = grobjects.filter(function(obj) {return (obj.helipad && (obj!=exclude))});
        if (!helipads.length) {
            throw("No Helipads for the helicopter!");
        }
        var idx = getRandomInt(0,helipads.length);
        return helipads[idx];
    }

    // this actually does the work
    function advance(heli, drawingState) {
        // on the first call, the copter does nothing
        if (!heli.lastTime) {
            heli.lastTime = drawingState.realtime;
            return;
        }
        var delta = drawingState.realtime - heli.lastTime;
        heli.lastTime = drawingState.realtime;

        // now do the right thing depending on state
        switch (heli.state) {
            case 0: // on the ground, waiting for take off
                if (heli.wait > 0) { heli.wait -= delta; }
                else {  // take off!
                    heli.state = 1;
                    heli.wait = 0;
                }
                break;
            case 1: // taking off
                if (heli.position[1] < altitude) {
                    var up = verticalSpeed * delta;
                    heli.position[1] = Math.min(altitude,heli.position[1]+up);
					var dtheta = heli.dir - heli.orientation;
					
					heli.orientation = heli.orientation - turningSpeed * delta;
					
					
                } else { // we've reached altitude - pick a destination
                    var dest = randomHelipad(heli.lastPad);
                    heli.lastPad = dest;
                    // the direction to get there...
                    heli.dx = dest.position[0] - heli.position[0];
                    heli.dz = dest.position[2] - heli.position[2];
                    heli.dst = Math.sqrt(heli.dx*heli.dx + heli.dz*heli.dz);
					heli.fly_dis = heli.dst;
                    if (heli.dst < .01) {
                        // small distance - just go there
                        heli.position[0] = dest.position[0];
                        heli.position[2] = dest.position[2];
                        heli.state = 4;
                     } else {
                        heli.vx = heli.dx / heli.dst;
                        heli.vz = heli.dz / heli.dst;
                    }
                    heli.dir = Math.atan2(heli.dx,heli.dz);
                    heli.state = 2;
                }
                break;
            case 2: // spin towards goal
                var dtheta = heli.dir - heli.orientation;
                // if we're close, pretend we're there
                if (Math.abs(dtheta) < .01) {
                    heli.state = 3;
                    heli.orientation = heli.dir;
                }
				
                var rotAmt = turningSpeed * delta;
                if (dtheta > 0) {
                    heli.orientation = Math.min(heli.dir,heli.orientation+rotAmt);
                } else {
                    heli.orientation = Math.max(heli.dir,heli.orientation-rotAmt);
                }
				
                break;
            case 3: // fly towards goal
                if (heli.dst > .01) {
                    var go = delta * flyingSpeed;
                    // don't go farther than goal
                    go = Math.min(heli.dst,go);
                    heli.position[0] += heli.vx * go;
                    heli.position[2] += heli.vz * go;
                    heli.dst -= go;
					if (heli.dst >= (heli.fly_dis/4)*3){
						heli.position[1] += 0.03;
					} else if(heli.dst >= (heli.fly_dis/4)*2){
						heli.position[1] -= 0.03;
					} else if(heli.dst >= (heli.fly_dis/4)*1){
						heli.position[1] += 0.03;
					} else {
						heli.position[1] -= 0.03;
					}
                } else { // we're effectively there, so go there
                    heli.position[0] = heli.lastPad.position[0];
                    heli.position[2] = heli.lastPad.position[2];
                    heli.state = 4;
                }
                break;
            case 4: // land at goal
                var destAlt = heli.lastPad.position[1] + .5 + heli.lastPad.helipadAltitude;
                if (heli.position[1] > destAlt) {
                    var down = delta * verticalSpeed;
                    heli.position[1] = Math.max(destAlt,heli.position[1]-down);
                } else { // on the ground!
                    heli.state = 0;
                    heli.wait = getRandomInt(500,1000);
                }
                break;
        }
    }
})();

// normally, I would put this into a "scene description" file, but having
// it here means if this file isn't loaded, then there are no dangling
// references to it

// make the objects and put them into the world
// note that the helipads float above the floor to avoid z-fighting
grobjects.push(new Copter());
grobjects.push(new Helipad([3,.01,3]));
grobjects.push(new Helipad([3,.01,-3]));
grobjects.push(new Helipad([-3,.01,-3]));
grobjects.push(new Helipad([-3,.01,3]));

// just to show - if there's a cube, we can land on it
var acube = findObj("cube1");
if (acube) {
    acube.helipad = true;
    acube.helipadAltitude = .5;
}
