var grobjects = grobjects || [];


(function() {
    "use strict";

    var vertexSource = [
		'uniform mat4 projection;',
		'uniform mat4 modelview;',
		'attribute vec3 coords;',
		'varying vec3 vCoords;',
		'void main() {',
		'	vec4 eyeCoords = modelview * vec4(coords,1.0);',
		'	gl_Position = projection * eyeCoords;',
		'	vCoords = coords;',
		'}',
	].join('\n');
		
    var fragmentSource = [
		'precision mediump float;',
		'varying vec3 vCoords;',
		'uniform samplerCube skybox;',
		'void main() {',
		'	gl_FragColor = textureCube(skybox, vCoords);',
		'}',
	].join('\n');
	
	var vertexSource_sphere = [
		'uniform mat4 projection;',
		'uniform mat4 modelview;',
		'attribute vec3 coords;',
		'attribute vec3 normal;',
		'varying vec3 viewCoords;',
		'varying vec3 vNormal;',
		'void main() {',
		'	vec4 eyeCoords = modelview * vec4(coords,1.0);',
		'	gl_Position = projection * eyeCoords;',
		'	viewCoords = eyeCoords.xyz;',
		'	vNormal = normal;',
		'}',
	].join('\n');
	
	var fragmentSource_sphere = [
		'precision mediump float;',
		'varying vec3 vCoords;',
		'varying vec3 vNormal;',
		'varying vec3 viewCoords;',
		'uniform samplerCube skybox;',
		'uniform mat3 normalMatrix;',
		'uniform mat3 invVT;',
		'void main() {',
		'	vec3 N = normalMatrix * vNormal;',
		'	vec3 V = -viewCoords;',
		'	vec3 R = 2.0 * dot(V,N) * N - V;',
		'	R = invVT * R; // Transform by inverse of view transform, which was applied to the skybox',
		'	gl_FragColor = textureCube(skybox, R);',
		'}',
	].join('\n');
		
    var skybox = {
        name : "skybox",
		
        init : function(drawingState) {
            // an abbreviation...
            var gl = drawingState.gl;

            // compile the vertex shader
            var vertexShader = gl.createShader(gl.VERTEX_SHADER);
            gl.shaderSource(vertexShader,vertexSource);
            gl.compileShader(vertexShader);
              if (!gl.getShaderParameter(vertexShader, gl.COMPILE_STATUS)) {
                      alert(gl.getShaderInfoLog(vertexShader));
                      return null;
                  }
            // now compile the fragment shader
            var fragmentShader = gl.createShader(gl.FRAGMENT_SHADER);
            gl.shaderSource(fragmentShader,fragmentSource);
            gl.compileShader(fragmentShader);
            if (!gl.getShaderParameter(fragmentShader, gl.COMPILE_STATUS)) {
                  alert(gl.getShaderInfoLog(fragmentShader));
                  return null;
            }
            // OK, we have a pair of shaders, we need to put them together
            // into a "shader program" object
            // notice that I am assuming that I can use "this"
            this.shaderProgram = gl.createProgram();
            gl.attachShader(this.shaderProgram, vertexShader);
            gl.attachShader(this.shaderProgram, fragmentShader);
            gl.linkProgram(this.shaderProgram);
            if (!gl.getProgramParameter(this.shaderProgram, gl.LINK_STATUS)) {
                alert("Could not initialize shaders");
            }
			
			// for sphere 
			// compile the vertex shader
            var vertexShader_s = gl.createShader(gl.VERTEX_SHADER);
            gl.shaderSource(vertexShader_s, vertexSource_sphere);
            gl.compileShader(vertexShader_s);
            if (!gl.getShaderParameter(vertexShader_s, gl.COMPILE_STATUS)) {
                      alert(gl.getShaderInfoLog(vertexShader_s));
                      return null;
            }
            // now compile the fragment shader
            var fragmentShader_s = gl.createShader(gl.FRAGMENT_SHADER);
            gl.shaderSource(fragmentShader_s, fragmentSource_sphere);
            gl.compileShader(fragmentShader_s);
            if (!gl.getShaderParameter(fragmentShader_s, gl.COMPILE_STATUS)) {
                  alert(gl.getShaderInfoLog(fragmentShader_s));
                  return null;
            }
            // OK, we have a pair of shaders, we need to put them together
            // into a "shader program" object
            // notice that I am assuming that I can use "this"
            this.shaderProgram_sphere = gl.createProgram();
            gl.attachShader(this.shaderProgram_sphere, vertexShader_s);
            gl.attachShader(this.shaderProgram_sphere, fragmentShader_s);
            gl.linkProgram(this.shaderProgram_sphere);
            if (!gl.getProgramParameter(this.shaderProgram_sphere, gl.LINK_STATUS)) {
                alert("Could not initialize shaders");
            }
			
			// six images
			var g_skyBoxUrls = [
				// pos x
				'https://farm1.staticflickr.com/870/26819315807_71ca97287e_b.jpg',
				// neg x
				'https://farm1.staticflickr.com/982/39880454760_1c2176bd94_b.jpg',
				// neg y
				'https://farm1.staticflickr.com/977/39880454380_ff4b05dfdb_b.jpg',
				// pos y
				'https://farm1.staticflickr.com/947/39880453880_dfcd5ba6c0_b.jpg',
				// pos z
				'https://farm1.staticflickr.com/869/26819315177_7d5098d596_b.jpg',
				// neg z
				'https://farm1.staticflickr.com/970/39880454340_d9b2e43142_b.jpg',
			];
            
			// cube box
			// vertices, normals, texCoords, indices
			var s = 200;
			this.far = s;
			var coords = [];
			var normals = [];
			var texCoords = [];
			var indices = [];
			
			function face(xyz, nrm) {
				var start = coords.length/3;
				var i;
				for (i = 0; i < 12; i++) {
					coords.push(xyz[i]);
				}
				for (i = 0; i < 4; i++) {
					normals.push(nrm[0],nrm[1],nrm[2]);
				}
				texCoords.push(0,0,1,0,1,1,0,1);
				indices.push(start,start+1,start+2,start,start+2,start+3);
			};
			
			face( [-s,-s,s, s,-s,s, s,s,s, -s,s,s], [0,0,1] );
			face( [-s,-s,-s, -s,s,-s, s,s,-s, s,-s,-s], [0,0,-1] );
			face( [-s,s,-s, -s,s,s, s,s,s, s,s,-s], [0,1,0] );
			face( [-s,-s,-s, s,-s,-s, s,-s,s, -s,-s,s], [0,-1,0] );
			face( [s,-s,-s, s,s,-s, s,s,s, s,-s,s], [1,0,0] );
			face( [-s,-s,-s, -s,-s,s, -s,s,s, -s,s,-s], [-1,0,0] );
			
			this.vertexPositions = new Float32Array(coords);
			this.vertexNormals = new Float32Array(normals);
			this.vertexTextureCoords = new Float32Array(texCoords);
			this.indices = new Uint16Array(indices);
			
			// sphere
			var radius = 1;
			var slices = 32;
			var stacks = 16;
			var vertexCount = (slices+1)*(stacks+1);
			var vertices = new Float32Array( 3*vertexCount );
			var normals = new Float32Array( 3* vertexCount );
			var texCoords = new Float32Array( 2*vertexCount );
			var indices = new Uint16Array( 2*slices*stacks*3 );
			var du = 2*Math.PI/slices;
			var dv = Math.PI/stacks;
			var i,j,u,v,x,y,z;
			var indexV = 0;
			var indexT = 0;
			for (i = 0; i <= stacks; i++) {
				v = -Math.PI/2 + i*dv;
				for (j = 0; j <= slices; j++) {
					u = j*du;
					x = Math.cos(u)*Math.cos(v);
					y = Math.sin(u)*Math.cos(v);
					z = Math.sin(v);
					vertices[indexV] = radius*x;
					normals[indexV++] = x;
					vertices[indexV] = radius*y;
					normals[indexV++] = y;
					vertices[indexV] = radius*z;
					normals[indexV++] = z;
					texCoords[indexT++] = j/slices;
					texCoords[indexT++] = i/stacks;
				} 
			}
			var k = 0;
			for (j = 0; j < stacks; j++) {
				var row1 = j*(slices+1);
				var row2 = (j+1)*(slices+1);
				for (i = 0; i < slices; i++) {
					indices[k++] = row1 + i;
					indices[k++] = row2 + i + 1;
					indices[k++] = row2 + i;
					indices[k++] = row1 + i;
					indices[k++] = row1 + i + 1;
					indices[k++] = row2 + i + 1;
				}
			}
			this.vertexPositions_sphere = vertices;
			this.vertexNormals_sphere = normals;
			this.vertexTextureCoords_sphere = texCoords;
			this.indices_sphere = indices;
			
			// get location 
			// for skybox
			this.aCoords =  gl.getAttribLocation(this.shaderProgram, "coords");
			this.uModelview = gl.getUniformLocation(this.shaderProgram, "modelview");
			this.uProjection = gl.getUniformLocation(this.shaderProgram, "projection");
			
			// for sphere
			this.aCoords_sphere =  gl.getAttribLocation(this.shaderProgram_sphere, "coords");
			this.aNormal_sphere =  gl.getAttribLocation(this.shaderProgram_sphere, "normal");
			this.uModelview_sphere = gl.getUniformLocation(this.shaderProgram_sphere, "modelview");
			this.uProjection_sphere = gl.getUniformLocation(this.shaderProgram_sphere, "projection");
			this.uNormalMatrix_sphere = gl.getUniformLocation(this.shaderProgram_sphere, "normalMatrix");
			this.uInvVT_sphere = gl.getUniformLocation(this.shaderProgram_sphere, "invVT");
			
			
			// create buffer
			// for skybox
			this.coordsBuffer = gl.createBuffer();
			gl.bindBuffer(gl.ARRAY_BUFFER, this.coordsBuffer);
			gl.bufferData(gl.ARRAY_BUFFER, this.vertexPositions, gl.STATIC_DRAW);
			
			this.indexBuffer = gl.createBuffer();
			gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.indexBuffer);
			gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, this.indices, gl.STATIC_DRAW);

			var ct = 0;
			var img = new Array(6);
			var texID;
			for (var i = 0; i < 6; i++) {
				img[i] = new Image();
				img[i].crossOrigin = "anonymous";
				img[i].onload = function() {
					ct++;
					if (ct == 6) {
						texID = gl.createTexture();
						gl.bindTexture(gl.TEXTURE_CUBE_MAP, texID);

						var targets = [
							gl.TEXTURE_CUBE_MAP_POSITIVE_X, gl.TEXTURE_CUBE_MAP_NEGATIVE_X, 
							gl.TEXTURE_CUBE_MAP_POSITIVE_Y, gl.TEXTURE_CUBE_MAP_NEGATIVE_Y, 
							gl.TEXTURE_CUBE_MAP_POSITIVE_Z, gl.TEXTURE_CUBE_MAP_NEGATIVE_Z 
						];

						for (var j = 0; j < 6; j++) {
							gl.texImage2D(targets[j], 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, img[j]);
							gl.texParameteri(gl.TEXTURE_CUBE_MAP, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
							gl.texParameteri(gl.TEXTURE_CUBE_MAP, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
						}
						gl.generateMipmap(gl.TEXTURE_CUBE_MAP);
					}
				}
            img[i].src = g_skyBoxUrls[i];
			};
			
			// for sphere
			this.coordsBuffer_sphere = gl.createBuffer();
			gl.bindBuffer(gl.ARRAY_BUFFER, this.coordsBuffer_sphere);
			gl.bufferData(gl.ARRAY_BUFFER, this.vertexPositions_sphere, gl.STATIC_DRAW);
	
			this.normalBuffer_sphere = gl.createBuffer();
			gl.bindBuffer(gl.ARRAY_BUFFER, this.normalBuffer_sphere);
			gl.bufferData(gl.ARRAY_BUFFER, this.vertexNormals_sphere, gl.STATIC_DRAW);
	
			this.indexBuffer_sphere = gl.createBuffer();
			gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.indexBuffer_sphere);
			gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, this.indices_sphere, gl.STATIC_DRAW);
			
			gl.enable(gl.DEPTH_TEST);
		},
        draw : function(drawingState) {
            var gl = drawingState.gl;
	
            // choose the shader program we have compiled
            gl.useProgram(this.shaderProgram);
			
            // enable the attributes we had set up
            gl.enableVertexAttribArray(this.aCoords);
			
			gl.bindBuffer(gl.ARRAY_BUFFER, this.coordsBuffer);
            gl.vertexAttribPointer(this.aCoords, 3, gl.FLOAT, false, 0, 0);
			
			var Tproj = twgl.m4.identity();
			twgl.m4.perspective(Math.PI/3, 1, 1, this.far, Tproj);
			
			var modelview = twgl.m4.multiply(twgl.m4.rotationZ(Math.PI),
							twgl.m4.multiply(twgl.m4.scaling([0.5,0.5,0.5]), drawingState.view));
			
            gl.uniformMatrix4fv(this.uModelview, false, modelview);
			gl.uniformMatrix4fv(this.uProjection, false, Tproj);
			
            gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.indexBuffer);
            gl.drawElements(gl.TRIANGLES, this.indices.length, gl.UNSIGNED_SHORT, 0);
			
			gl.disableVertexAttribArray(this.aCoords);
			
			//
			// draw the sphere now
			gl.useProgram(this.shaderProgram_sphere);
			
			gl.enableVertexAttribArray(this.aCoords_sphere);
			gl.enableVertexAttribArray(this.aNormal_sphere);
			
			gl.bindBuffer(gl.ARRAY_BUFFER, this.coordsBuffer_sphere);
			gl.vertexAttribPointer(this.aCoords_sphere, 3, gl.FLOAT, false, 0, 0);
			
			gl.bindBuffer(gl.ARRAY_BUFFER, this.normalBuffer_sphere);
			gl.vertexAttribPointer(this.aNormal_sphere, 3, gl.FLOAT, false, 0, 0);
			
			var normalMatrix = mat3.create();
			var invVT = mat3.create();
			mat3.normalFromMat4(normalMatrix, modelview);
			mat3.fromMat4(invVT, modelview);
			mat3.invert(invVT,invVT);
	
			gl.uniformMatrix4fv(this.uModelview_sphere, false, modelview );
			gl.uniformMatrix4fv(this.uProjection_sphere, false, Tproj);
			gl.uniformMatrix3fv(this.uNormalMatrix_sphere, false, normalMatrix);
			gl.uniformMatrix3fv(this.uInvVT_sphere, false, invVT);
			
			gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.indexBuffer_sphere);
			gl.drawElements(gl.TRIANGLES, this.indices_sphere.length, gl.UNSIGNED_SHORT, 0);
			
			gl.disableVertexAttribArray(this.aCoords_sphere);
			gl.disableVertexAttribArray(this.aNormal_sphere);
        },
        center : function(drawingState) {
            return [0,.5,0];
        },

        // these are the internal methods / fields of this specific object
        // we want to keep the shaders and buffers - rather than rebuild them
        // every draw. we can't initialize them now, but rather we need to wait
        // until there is a GL context (when we call init)
        // technically, these don't need to be defined here - init can just
        // add fields to the object - but I am putting them here  since it feels
        // more like a normal "class" declaration
        shaderProgram : undefined,
        posBuffer : undefined,
        posLoc : -1,
        colorLoc : -1,
        projLoc : -1,
        viewLoc : -1
    };

    // now that we've defined the object, add it to the global objects list
    grobjects.push(skybox);
})();